import React, { useState } from "react";
import styled from "styled-components";
import Editor from "./pages/Editor/Editor";
import './App.scss';

const AppDiv = styled.div`

`;

const App = (props) =>{

  let [darkThemeHome,setDarkThemeHome]=useState(false);

  return(
    <AppDiv>
      <Editor darkThemeHome={darkThemeHome} {...props}/>
    </AppDiv>
  )
}
export default App;