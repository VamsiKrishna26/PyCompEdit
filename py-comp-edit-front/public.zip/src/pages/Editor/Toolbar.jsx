import React from "react";
import { Dropdown, DropdownButton } from "react-bootstrap";
import styled from "styled-components";

const ToolbarDiv = styled.div`
  .toolbar-div {
    display: flex;
    align-items: center;
    justify-content: space-evenly;
    height: auto;

    .dropdown {
      margin: 0.5em;
    }
  }
`;

const StyledDropDownToggle = styled(Dropdown.Toggle)`
  font-family: ${(props) => props.fontFamily};
  color: ${(props) => (props.$darkTheme ? "white" : "black")} ;
  background-color: ${(props) =>
    props.$darkTheme ? "rgb(44,44,44)" : "white"} ;
  border: ${(props) => (props.$darkTheme ? "" : "1px solid black")};
  :focus {
    font-family: ${(props) => props.fontFamily} !important;
    color: ${(props) => (props.$darkTheme ? "white" : "black")} !important;
    background-color: ${(props) =>
      props.$darkTheme ? "rgb(44,44,44)" : "white"} !important;
  }
  :hover {
    color: ${(props) => (props.$darkTheme ? "black" : "white")};
    background-color: ${(props) =>
      props.$darkTheme ? "white" : "rgb(44,44,44)"};
  }
`;

const StyledDropDownMenu = styled(Dropdown.Menu)`
  background-color: ${(props) =>
    props.$darkTheme ? "rgb(44,44,44)" : "white"} ;
`;

const StyledDropDownItem = styled(Dropdown.Item)`
  font-family: ${(props) => props.fontFamily};
  color: ${(props) => (props.$darkTheme ? "white" : "black")};
  background-color: ${(props) =>
    props.$darkTheme ? "rgb(44,44,44)" : "white"};
`;

const Toolbar = (props) => {
  const {
    changeFontSize,
    fontSize,
    fontFamily,
    darkTheme,
    changeFontWeight,
    fontWeight,
    changeFontFamily,
  } = props;

  const font_families_list = [
    "'Source Code Pro', monospace",
    "'JetBrains Mono', monospace",
    "'Roboto Mono', monospace",
    "'Ubuntu Mono', monospace",
    "'Kanit', sans-serif",
    "'Lato', sans-serif",
    "'Lora', serif",
    "'Raleway', sans-serif",
    "'Roboto', sans-serif",
    "'Ubuntu', sans-serif",
    "'Mukta', sans-serif",
    "'Nunito Sans', sans-serif",
  ];

  const font_sizes = () => {
    let fontSizes = [];
    for (var i = 10; i <= 28; i += 2) {
      fontSizes.push(
        <StyledDropDownItem
          fontFamily={fontFamily}
          $darkTheme={darkTheme}
          eventKey={i}
          key={i}
        >
          {i}
        </StyledDropDownItem>
      );
    }
    return fontSizes;
  };

  const font_weights = () => {
    let fontWeights = [];
    for (var i = 100; i <= 900; i += 100) {
      fontWeights.push(
        <StyledDropDownItem
          fontFamily={fontFamily}
          $darkTheme={darkTheme}
          eventKey={i}
          key={i}
        >
          {i}
        </StyledDropDownItem>
      );
    }
    return fontWeights;
  };

  const font_families = () => {
    let fontFamilies = [];
    for (var i = 0; i < font_families_list.length; i += 1) {
      fontFamilies.push(
        <StyledDropDownItem
          fontFamily={font_families_list[i]}
          $darkTheme={darkTheme}
          eventKey={font_families_list[i]}
          key={font_families_list[i]}
        >
          {font_families_list[i]}
        </StyledDropDownItem>
      );
    }
    return fontFamilies;
  };

  return (
    <ToolbarDiv>
      <div className="toolbar-div">
        <Dropdown
          variant="custom"
          onSelect={changeFontFamily}
          className="dropdown"
        >
          <StyledDropDownToggle
            className="dropdown-font"
            fontFamily={fontFamily}
            $darkTheme={darkTheme}
          >
            {`Font: ${fontFamily.match(/'[\w ]+'/)}`}
          </StyledDropDownToggle>

          <StyledDropDownMenu $darkTheme={darkTheme}>
            {font_families()}
          </StyledDropDownMenu>
        </Dropdown>
        <Dropdown
          variant="custom"
          onSelect={changeFontSize}
          className="dropdown"
        >
          <StyledDropDownToggle fontFamily={fontFamily} $darkTheme={darkTheme}>
            {`Font-size: ${fontSize.slice(0, 2)}`}
          </StyledDropDownToggle>

          <StyledDropDownMenu $darkTheme={darkTheme}>
            {font_sizes()}
          </StyledDropDownMenu>
        </Dropdown>
        <Dropdown variant="custom" onSelect={changeFontWeight}>
          <StyledDropDownToggle fontFamily={fontFamily} $darkTheme={darkTheme}>
            {`Font-weight: ${fontWeight}`}
          </StyledDropDownToggle>

          <StyledDropDownMenu $darkTheme={darkTheme}>
            {font_weights()}
          </StyledDropDownMenu>
        </Dropdown>
      </div>
    </ToolbarDiv>
  );
};

export default Toolbar;
