import React, { useEffect, useState } from "react";
import { Button, Form } from "react-bootstrap";
import { Node } from "slate";
import styled from "styled-components";
import DisplayResult from "./DisplayResult";
import LoadingScreen from "./LoadingScreen";
import RunButton from "./RunButton";
import TextEditor from "./TextEditor";
import Toolbar from "./Toolbar";

const EditorDiv = styled.div`
  .editor-area {
    display: flex;
    justify-content: center;
    flex-direction: column;

    .editor {
      margin: 1em;
      position: relative;
      display: flex;
      flex-direction: column;

      .time-difference {
        display: flex;
        align-items: center;
        justify-content: flex-end;
        margin: 0.35em;
        margin-right: 1.5em;
      }

      .button-area {
        display: flex;
        flex-direction: row;
        align-items: flex-end;
        justify-content: center;
        margin: 0.4em;
        margin-left: 1em;

        .upload-label {
          font-family: ${(props) => props.fontFamily};
          margin-right: 0.5em;
        }
      }

      .extras {
        display: flex;
        /* align-items: center; */
        flex-direction: row;
        /* border: 1px solid red; */

        .file_name-stdin {
          flex: 0.5;
          display: flex;
          justify-content: center;
          flex-direction: column;
          /* border: 1px solid black; */
        }

        .notes {
          flex: 0.5;
          display: flex;
          justify-content: center;
          align-items: center;
          /* border: 1px solid black; */
          margin: 0.5em;
          .notes-area {
            flex: 1;
            height: 100%;
            
          }
        }
      }
    }

    .display {
      display: flex;
      align-items: ${(props) => (props.isFetching ? "center" : "flex-start")};
      justify-content: ${(props) =>
        props.isFetching ? "center" : "flex-start"};
      margin: 1em;
      position: relative;
      border-radius: 15px 15px 15px 15px;
      border: 1px solid black;
      padding: 1em;
      background-color: ${(props) =>
        props.darkTheme ? "rgb(44,44,44)" : "white"};
      min-height: 200px !important;
      max-height: 400px !important;
      width: auto;
      position: relative;
    }
  }

  .stdin_file-name {
    border-radius: 15px 15px 15px 15px;
    border: 1px solid black;
    padding: 1em;
    background-color: ${(props) =>
      props.darkTheme ? "rgb(44,44,44)" : "white"};
    font-family: ${(props) => props.fontFamily};
    font-size: ${(props) => props.fontSize};
    font-weight: ${(props) => props.fontWeight};
    color: ${(props) => (props.darkTheme ? "white" : "black")};
    margin: 0.5em;
  }
`;

const StyledFormControl = styled(Form.Control)`
  width: 320px;
  :focus {
    font-family: ${(props) => props.fontFamily};
    color: ${(props) => (props.$darkTheme ? "white" : "black")};
    background-color: ${(props) =>
      props.$darkTheme ? "rgb(44,44,44)" : "white"};
  }
  :not(active) {
    font-family: ${(props) => props.fontFamily};
    color: ${(props) => (props.$darkTheme ? "white" : "black")};
    background-color: ${(props) =>
      props.$darkTheme ? "rgb(44,44,44)" : "white"};
  }
`;

const StyledDownloadButton = styled(Button)`
  font-family: ${(props) => props.fontFamily};
  color: ${(props) => (props.$darkTheme ? "white" : "black")};
  background-color: ${(props) =>
    props.$darkTheme ? "rgb(44,44,44)" : "white"};
  margin-left: 0.5em;
  border: ${(props) => (props.$darkTheme ? "" : "1px solid black")};
  :hover {
    color: ${(props) => (props.$darkTheme ? "black" : "white")};
    background-color: ${(props) =>
      props.$darkTheme ? "white" : "rgb(44,44,44)"};
  }
`;

const Editor = (props) => {
  const { darkThemeHome } = props;

  useEffect(() => {
    setDarkTheme(darkThemeHome);
  }, [darkThemeHome]);

  let [codeString, setCodeString] = useState(null);

  let [stdin, setStdin] = useState("");

  let [fileName, setFileName] = useState(
    JSON.parse(localStorage.getItem("file_name")) || "Script1"
  );

  let [fontFamily, setFontFamily] = useState(
    JSON.parse(localStorage.getItem("font_family")) ||
      "'Source Code Pro', monospace"
  );

  let [fontWeight, setFontWeight] = useState(
    JSON.parse(localStorage.getItem("font_weight")) || 400
  );

  let [fontSize, setFontSize] = useState(
    JSON.parse(localStorage.getItem("font_size")) || "16px"
  );

  let [darkTheme, setDarkTheme] = useState(false);

  let [result, setResult] = useState({});

  let [isFetching, setIsFetching] = useState(false);

  let [uploadFileText, setUploadFileText] = useState(null);

  let [timeDifference, setTimeDifference] = useState(0);

  let [notes, setNotes] = useState(
    JSON.parse(localStorage.getItem("notes")) || ""
  );

  const codeStringChange = (code) => {
    setCodeString(code.map((node) => Node.string(node)).join("\n"));
  };

  const changeFontSize = (size) => {
    if (size) setFontSize(size + "px");
  };

  useEffect(() => {
    localStorage.setItem("font_size", JSON.stringify(fontSize));
  }, [fontSize]);

  const changeFontWeight = (weight) => {
    if (weight) setFontWeight(weight);
  };

  useEffect(() => {
    localStorage.setItem("font_weight", JSON.stringify(fontWeight));
  }, [fontWeight]);

  const changeFontFamily = (font) => {
    if (font) setFontFamily(font);
  };

  useEffect(() => {
    localStorage.setItem("font_family", JSON.stringify(fontFamily));
  }, [fontFamily]);

  const fetchSubmission = () => {
    setIsFetching(true);
    fetch("http://localhost:1020/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ source_code: codeString, stdin: stdin }),
    })
      .then((response) => response.json())
      .then((data) => {
        setResult(data);
        setIsFetching(false);
      })
      .catch((error) => {
        console.log(error);
        setIsFetching(false);
      });
  };

  const onChange = (e) => {
    setStdin(e.target.value);
  };

  const onFileNameChange = (e) => {
    setFileName(e.target.value);
  };

  const onChangeNotes = (e) => {
    setNotes(e.target.value);
  };

  const uploadFile = async (e) => {
    try {
      e.preventDefault();
      const reader = new FileReader();
      reader.onload = async (e) => {
        const text = e.target.result;
        setUploadFileText(text);
      };
      reader.readAsText(e.target.files[0]);
    } catch (err) {
      console.log(err);
    }
  };

  const downloadFile = () => {
    const element = document.createElement("a");
    const file = new Blob([codeString], { type: "text/plain" });
    element.href = URL.createObjectURL(file);
    element.download = `${fileName}.py`;
    document.body.appendChild(element);
    element.click();
  };

  return (
    <EditorDiv
      darkTheme={darkTheme}
      fontFamily={fontFamily}
      fontSize={fontSize}
      fontWeight={fontWeight}
      isFetching={isFetching}
    >
      <div className="editor-area">
        <div className="editor">
          <div>
            <Form.Group className="button-area">
              <Form.Label className="upload-label">
                Upload a Local File:{" "}
              </Form.Label>
              <StyledFormControl
                id="uploadFile"
                fontFamily={fontFamily}
                $darkTheme={darkTheme}
                type="file"
                accept=".py"
                onChange={uploadFile}
              />
              <StyledDownloadButton
                variant="custom"
                fontFamily={fontFamily}
                $darkTheme={darkTheme}
                onClick={downloadFile}
              >
                Download as .py
              </StyledDownloadButton>
            </Form.Group>
          </div>
          <Toolbar
            {...props}
            fontFamily={fontFamily}
            fontSize={fontSize}
            darkTheme={darkTheme}
            fontWeight={fontWeight}
            changeFontSize={changeFontSize}
            changeFontWeight={changeFontWeight}
            changeFontFamily={changeFontFamily}
          />
          <span className="time-difference">{`Code saved ${timeDifference} seconds ago...`}</span>
          <TextEditor
            {...props}
            uploadFileText={uploadFileText}
            fontFamily={fontFamily}
            fontSize={fontSize}
            darkTheme={darkTheme}
            fontWeight={fontWeight}
            codeStringChange={codeStringChange}
            result={result}
            setTimeDifference={setTimeDifference}
          />
          <div className="extras">
            <div className="file_name-stdin">
              <input
                onChange={onFileNameChange}
                className="stdin_file-name"
                type="text"
                name="file-name"
                value={fileName}
                spellCheck="false"
              />
              <input
                onChange={onChange}
                className="stdin_file-name"
                type="text"
                name="stdin"
                value={stdin}
                spellCheck="false"
              />
            </div>
            <div className="notes">
              <textarea
                onChange={onChangeNotes}
                className="stdin_file-name notes-area"
                type="text"
                name="notes"
                value={notes}
              />
            </div>
          </div>
        </div>
        <RunButton
          fontFamily={fontFamily}
          fontSize={fontSize}
          darkTheme={darkTheme}
          fontWeight={fontWeight}
          fetchSubmission={fetchSubmission}
        />
        <div className="display">
          {!isFetching ? (
            <DisplayResult
              {...props}
              fontFamily={fontFamily}
              fontSize={fontSize}
              darkTheme={darkTheme}
              fontWeight={fontWeight}
              result={result}
            />
          ) : (
            <LoadingScreen darkTheme={darkTheme} />
          )}
        </div>
      </div>
    </EditorDiv>
  );
};

export default Editor;
