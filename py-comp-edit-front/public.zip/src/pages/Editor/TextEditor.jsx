import React, { useCallback, useEffect, useState } from "react";
import { createEditor, Text, Transforms, Editor } from "slate";
import { withHistory } from "slate-history";
import { Editable, Slate, withReact } from "slate-react";
import styled from "styled-components";
import * as Prism from "prismjs";
import "prismjs/components/prism-python";
import { css } from "@emotion/css";

const TextEditorDiv = styled.div`
  .text-editor-div {
    display: flex;
    flex-direction: row;
    // border: 1px solid red;
    overflow-y: auto;
    border-radius: 15px 15px 15px 15px;
    border: 1px solid black;
    padding: 1em;
    font-family: ${(props) => props.fontFamily};
    font-size: ${(props) => props.fontSize};
    font-weight: ${(props) => props.fontWeight};
    color: ${(props) => (props.darkTheme ? "white" : "black")};
    background-color: ${(props) =>
      props.darkTheme ? "rgb(44,44,44)" : "white"};
    min-height: 400px !important;
    max-height: 800px !important;
    width: auto;
    position: relative;
    margin-top: 0.5em;
    margin-bottom: 1em;

    .line-numbers {
      padding-left: 0.5em;
      flex: 0.05;
    }

    .text-editor {
      flex: 0.95;
    }
  }
`;

Prism.languages.python = Prism.languages.extend("python", {});
Prism.languages.insertBefore("python", "prolog", {
  comment: { pattern: /##[^\n]*/, alias: "comment" },
});

const TextEditor = (props) => {

  const language = "python";

  const {
    fontFamily,
    fontSize,
    darkTheme,
    codeStringChange,
    // result,
    fontWeight,
    uploadFileText,
    setTimeDifference
  } = props;

  // result.stderr='Traceback (most recent call last): File "script.py", line 97, in <module> first_player=prepare_cards() File "script.py", line 67, in prepare_cards shuffled=shuffle_card_deck(cards_deck) File "script.py", line 36, in shuffle_card_deck cards_list1[i]=cards_list2[m] NameError: name "m" is not defined';

  let [editor] = useState(() => withHistory(withReact(createEditor())), []);

  // let [lineNumberError, setLineNumberError] = useState();

  let [timer,setTimer]=useState(Math.floor(new Date().getTime()));

  let [presentTimer,setPresentTimer]=useState(Math.floor(new Date().getTime()));


  // useEffect(()=>{console.log(timer)},[timer]);

  useEffect(()=>{
    const interval=setInterval(()=>{
      setPresentTimer(presentTimer=>presentTimer+5000);
    },5000);
    return ()=>clearInterval(interval);
  },[])

  useEffect(()=>{
    setTimeDifference(Math.abs(Math.floor(presentTimer/1000)-Math.floor(timer/1000)));
  },[presentTimer,timer]);

  useEffect(() => {
    if (uploadFileText) {
      let lines = uploadFileText.split("\n");
      Transforms.delete(editor, {
        at: {
          anchor: Editor.start(editor, []),
          focus: Editor.end(editor, []),
        },
      });
      for (var i = 0; i < lines.length; i++) {
        if (lines[i] === "\r") {
          Transforms.insertNodes(editor, {
            type: "paragraph",
            children: [{ text: "" }],
          });
        } else {
          Transforms.insertNodes(editor, {
            type: "paragraph",
            children: [{ text: lines[i] }],
          });
        }
      }
    }
  }, [uploadFileText]);

  let [code, setCode] = useState(JSON.parse(localStorage.getItem('prevText'))|| [
    {
      type: "paragraph",
      children: [
        {
          text: "#Type your code here...",
        },
      ],
    },
    {
      type: "paragraph",
      children: [
        {
          text: "",
        },
      ],
    },
    {
      type: "paragraph",
      children: [
        {
          text: 'print("Hello World!!")',
        },
      ],
    },
    {
      type: "paragraph",
      children: [
        {
          text: "",
        },
      ],
    },
  ]);

  let [noOfLines, setNoOfLines] = useState(0);

  const Leaf = ({ attributes, children, leaf }) => {
    return (
      <span
        {...attributes}
        className={css`
          ${leaf.comment &&
          css`
            color: #9f9698;
          `}
          ${(leaf.operator || leaf.url) &&
          css`
            color: ${props.darkTheme ? "#45b1dc" : "#6a3129"};
          `}
            ${leaf.keyword &&
          css`
            color: ${props.darkTheme ? "#56a6e2" : "#006699"};
          `}
            ${(leaf.variable || leaf.regex) &&
          css`
            color: ${props.darkTheme ? "#f82671" : "#19709b"};
          `}
            ${(leaf.number ||
            leaf.boolean ||
            leaf.tag ||
            leaf.constant ||
            leaf["attr-name"] ||
            leaf.selector) &&
          css`
            color: ${props.darkTheme ? "#c39076" : "#2c2a97"};
          `}
            ${leaf.punctuation &&
          css`
            color: ${props.darkTheme ? "#ad56a4" : "#ff2c96"};
          `}
            ${(leaf.string || leaf.char) &&
          css`
            color: ${props.darkTheme ? "#2e8442" : "#048165"};
          `}
            ${(leaf.function || leaf["class-name"]) &&
          css`
            color: ${props.darkTheme ? "#dbdba3" : "#162f59"};
          `}
        `}
      >
        {children}
      </span>
    );
  };

  const getLength = (token) => {
    if (typeof token === "string") {
      return token.length;
    } else if (typeof token.content === "string") {
      return token.content.length;
    } else {
      return token.content.reduce((l, t) => l + getLength(t), 0);
    }
  };

  useEffect(() => {
    setNoOfLines(editor.children.length);
  }, [editor.children]);

  const decorate = useCallback(
    ([node, path]) => {
      const ranges = [];
      if (!Text.isText(node)) {
        return ranges;
      }
      const tokens = Prism.tokenize(node.text, Prism.languages[language]);
      let start = 0;
      for (let token = 0; token < tokens.length; token++) {
        const length = getLength(tokens[token]);
        const end = start + length;
        if (typeof tokens[token] !== "string") {
          ranges.push({
            [tokens[token].type]: true,
            anchor: { path, offset: start },
            focus: { path, offset: end },
          });
        }
        start = end;
      }

      return ranges;
    },
    [language]
  );

  const onKeyDown = (e) => {
    if (e.key === "Tab") {
      e.preventDefault();
      editor.insertText("    ");
    } 
    else if (e.key === "Enter") {
      e.preventDefault();
      let prev_node_text = Editor.node(editor, editor.selection)[0].text;
      let leading_spaces = prev_node_text.search(/\S|$/);
      if (leading_spaces === 0) {
        var count = 0;
        var index = 0;
        while (prev_node_text.charAt(index++) === "\t") {
          count++;
        }
        leading_spaces = count * 4;
        console.log(leading_spaces);
      }
      if (prev_node_text[prev_node_text.length - 1] === ":") {
        leading_spaces = leading_spaces === 0 ? 4 : (leading_spaces += 4);
      } else if (prev_node_text.match(/return/)) {
        leading_spaces = leading_spaces === 4 ? 0 : (leading_spaces -= 4);
      }
      Transforms.insertNodes(editor, {
        type: "paragraph",
        children: [{ text: " ".repeat(leading_spaces) }],
      });
    } 
    else if (e.key === "{") {
      e.preventDefault();
      editor.insertText("{}");
      Transforms.move(editor, { distance: 1, reverse: true });
    } else if (e.key === "(") {
      e.preventDefault();
      editor.insertText("()");
      Transforms.move(editor, { distance: 1, reverse: true });
    } else if (e.key === "[") {
      e.preventDefault();
      editor.insertText("[]");
      Transforms.move(editor, { distance: 1, reverse: true });
    } else if (e.key === '"') {
      e.preventDefault();
      editor.insertText('""');
      Transforms.move(editor, { distance: 1, reverse: true });
    }
    let charCode = String.fromCharCode(e.which).toLowerCase();
    if ((e.ctrlKey || e.metaKey) && charCode === "s") {
      e.preventDefault();
      setCode(editor.children);
      setTimer(Math.floor(new Date().getTime()));
      setPresentTimer(Math.floor(new Date().getTime()));
    }
  };

  useEffect(() => {
    codeStringChange(code);
    localStorage.setItem('prevText',JSON.stringify(code));
  }, [code]);

  
  useEffect(() => {
    setCode(editor.children);
    const interval = setInterval(() => {
      setCode(editor.children);
      setTimer(Math.floor(new Date().getTime()));
      setPresentTimer(Math.floor(new Date().getTime()));
    }, 180000);
    return () => clearInterval(interval);
  }, []);

  const line_numbers = () => {
    let lineNumbers = [];
    noOfLines = noOfLines < 4 ? 4 : noOfLines;
    for (var i = 1; i <= noOfLines; i++) {
      lineNumbers.push(<div key={i}>{`${i}. `}</div>);
    }
    return lineNumbers;
  };

  // useEffect(() => {
  //   if (result.stderr) {
  //     let string_match = result.stderr.match(/line [0-9]+/g);
  //     if (string_match[string_match.length - 1]) {
  //       let line_number = parseInt(
  //         string_match[string_match.length - 1].slice(5)
  //       );
  //       setLineNumberError(3);
  //     }
  //   }
  // }, [result.stderr]);


  return (
    <TextEditorDiv
      fontFamily={fontFamily}
      fontSize={fontSize}
      fontWeight={fontWeight}
      darkTheme={darkTheme}
    >
      <div className="text-editor-div">
        <div className="line-numbers">{line_numbers()}</div>
        <div className="text-editor">
          <Slate editor={editor} value={code}>
            <Editable
              decorate={decorate}
              className="text-area"
              renderLeaf={(props) => <Leaf {...props} />}
              placeholder="Write some code..."
              onKeyDown={onKeyDown}
              spellCheck="false"
            ></Editable>
          </Slate>
        </div>
      </div>
    </TextEditorDiv>
  );
};

export default TextEditor;
